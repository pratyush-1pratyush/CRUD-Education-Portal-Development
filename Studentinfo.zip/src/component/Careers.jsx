import React from 'react'

const Careers = () => {
  return (
     <section className='Careers'>
      <div className='imageCareers'></div>
     </section>
  )
}

export default Careers
