import React from 'react'

const About = () => {
  return (
     <article id='aboutMain'>
      <section className='leftClass'>
        <div className='thought'> "Education is the passport to future, </div>
       <div className='thought2'>  for tomorrow belongs to those who prepare for it today."</div>
      </section>
      <section className='rightClass'></section>
     </article>
  )
}

export default About